package com.example.pressureapp

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.snackbar.Snackbar
import android.widget.Button
import android.widget.TextView

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val nameText = findViewById<TextView>(R.id.tvName)
        val idText = findViewById<TextView>(R.id.tvStudentId)
        val openBtn = findViewById<Button>(R.id.btnOpenPressure)

        // TODO: Replace with your actual name/ID
        nameText.text = "Name: Shayan Pourahmad"
        idText.text = "Student ID: 101474651"

        openBtn.setOnClickListener {
            startActivity(Intent(this, PressureActivity::class.java))
        }
    }

    // Options menu (worth 20 marks in rubric)
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_open_pressure -> {
                startActivity(Intent(this, PressureActivity::class.java))
                true
            }
            R.id.action_about -> {
                Snackbar.make(findViewById(android.R.id.content),
                    "Pressure App • Shows live barometric pressure (hPa)",
                    Snackbar.LENGTH_LONG).show()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
}
