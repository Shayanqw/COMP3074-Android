package com.example.pressureapp

import android.graphics.drawable.ColorDrawable
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import android.view.MenuItem
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class PressureActivity : AppCompatActivity(), SensorEventListener {

    private lateinit var sensorManager: SensorManager
    private var pressureSensor: Sensor? = null

    private lateinit var tvStatus: TextView
    private lateinit var tvPressure: TextView
    private lateinit var tvRangeHint: TextView
    private lateinit var demoSwitch: Switch
    private lateinit var demoSeek: SeekBar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pressure)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        // Back to Home button (must be AFTER setContentView)
        val backButton = findViewById<Button>(R.id.btnBackHome)
        backButton.setOnClickListener { finish() }

        tvStatus = findViewById(R.id.tvStatus)
        tvPressure = findViewById(R.id.tvPressure)
        tvRangeHint = findViewById(R.id.tvRangeHint)
        demoSwitch = findViewById(R.id.swDemo)
        demoSeek = findViewById(R.id.sbDemo)

        sensorManager = getSystemService(SENSOR_SERVICE) as SensorManager
        pressureSensor = sensorManager.getDefaultSensor(Sensor.TYPE_PRESSURE)

        val hasSensor = (pressureSensor != null)
        demoSwitch.isEnabled = !hasSensor
        demoSeek.isEnabled = !hasSensor

        if (!hasSensor) {
            tvStatus.text = "Barometer not found. Demo Mode enabled."
            demoSwitch.isChecked = true
        } else {
            tvStatus.text = "Reading live barometric pressure (hPa)…"
        }

        demoSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (demoSwitch.isChecked) {
                    val simulated = 900f + progress // 900–1100 hPa
                    updateUi(simulated)
                }
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        tvRangeHint.text = "Color map: <950 hPa = Gray, 950–1010 hPa = Blue, >1010 hPa = Yellow"
    }

    override fun onResume() {
        super.onResume()
        pressureSensor?.let {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_UI)
        }
    }

    override fun onPause() {
        super.onPause()
        sensorManager.unregisterListener(this)
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    override fun onSensorChanged(event: SensorEvent?) {
        if (event?.sensor?.type == Sensor.TYPE_PRESSURE && !demoSwitch.isChecked) {
            val hPa = event.values[0]
            updateUi(hPa)
        }
    }

    private fun updateUi(hPa: Float) {
        tvPressure.text = String.format("Pressure: %.2f hPa", hPa)

        val colorRes = when {
            hPa < 950f -> R.color.pressure_low_gray
            hPa <= 1010f -> R.color.pressure_normal_blue
            else -> R.color.pressure_high_yellow
        }
        val color = ContextCompat.getColor(this, colorRes)
        window.setBackgroundDrawable(ColorDrawable(color))

        val desc = when {
            hPa < 950f -> "Stormy / Low Pressure"
            hPa <= 1010f -> "Normal Weather"
            else -> "High Pressure / Sunny"
        }
        tvStatus.text = "Condition: $desc"
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home) {
            finish()
            return true
        }
        return super.onOptionsItemSelected(item)
    }
}
